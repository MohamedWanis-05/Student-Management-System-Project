/*
 * Student_management_project
 *
 *  Created on: Aug 10, 2025
 *      Author: Mohamed Mahmoud Nasr
 *      Authorized to : Edges for training
 */
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#define NAME_LEN 50
#define LINE_LEN 200



typedef struct student {
	int id ;			// student id
	char name[50];		// student name
	int age;			// student age
	float gpa;			// student gpa
}student;



// define a structure to present a node in a linked list

struct node {
    struct student data;
    struct node *next;
};
struct node *head = NULL;

/**********Functions prototype**********/

void addStudent(const struct student *const ptr);
void displayStudents(void);
void searchStudentByID(int id);
void updateStudent(int id);
float calculateAverageGPA(void);
void searchHighestGPA(void);
void deleteStudent(int id);


/******** A function to read a whole line from user ********/

void read_line(char *buf, size_t size) {
    if (fgets(buf, (int)size, stdin)) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n')
            buf[len - 1] = '\0';
    }
}



/************** searcing for a student using id **************/

struct node* find_by_id(int id) {
    struct node *cur = head;
    while (cur) {
        if (cur->data.id == id) return cur;
        cur = cur->next;
    }
    return NULL;
}


/*********** A function to add a new student ***********/

void addStudent(const struct student *const ptr) {

    // checking if the id is already there

    if (find_by_id(ptr->id)) {
        printf("Error: Student with ID %d already exists.\n", ptr->id);
        return; // stop adding if there was a student with the same id
    }

    // new node
    struct node *newNode = malloc(sizeof(struct node));
    if (!newNode) { // FAILED
        printf("Memory allocation failed.\n");
        return;
    }

    // copying student data
    newNode->data = *ptr;
    newNode->next = NULL;

    // Adding the student to the list
    if (!head) {
        head = newNode;
    } else {
        struct node *cur = head;
        while (cur->next) cur = cur->next;
        cur->next = newNode;
    }

    printf("Student with ID %d added successfully.\n", ptr->id);
}


/********** displaying all students**********/

void displayStudents(void) {
    if (!head) {
        printf("No students in the system.\n");
        return;
    }
    printf("ID\tName\t\tAge\tGPA\n");
    printf("----------------------------------------\n");
    struct node *cur = head;
    while (cur) {
        printf("%d\t%-15s\t%d\t%.2f\n",
               cur->data.id,
               cur->data.name,
               cur->data.age,
               cur->data.gpa);
        cur = cur->next;
    }
}


/************ searching for a student using id ************/

void searchStudentByID(int id) {
    struct node *s = find_by_id(id);
    if (!s) {
        printf("Student with ID %d not found.\n", id);
    } else {
        printf("Student found:/n ID: %d, Name: %s, Age: %d, GPA: %.2f",
               s->data.id, s->data.name, s->data.age, s->data.gpa);
    }
}


/****************** updating a student ******************/

void updateStudent(int id) {
    struct node *s = find_by_id(id);
    if (!s) {
        printf("Student with ID %d not found.\n", id);
        return;
    }
    char line[LINE_LEN];
    printf("Enter new name: ");
    read_line(s->data.name, sizeof(s->data.name));

    printf("Enter new age: ");
    read_line(line, sizeof(line));
    sscanf(line, "%d", &s->data.age);

    printf("Enter new GPA: ");
    read_line(line, sizeof(line));
    sscanf(line, "%f", &s->data.gpa);

    printf("Student with ID %d updated.\n", id);
}


/*************** deleting a student ***************/

void deleteStudent(int id) {
    struct node *cur = head;
    struct node *prev = NULL;
    while (cur) {
        if (cur->data.id == id) break;
        prev = cur;
        cur = cur->next;
    }

    if (!cur) {
        printf("Student with ID %d not found.\n", id);
        return;
    }

    if (!prev) {
        head = cur->next;
    } else {
        prev->next = cur->next;
    }
    free(cur);
    printf("Student with ID %d deleted.\n", id);
}


/*************** calculating average gpa ***************/

float calculateAverageGPA(void) {
    if (!head) return 0.0f;
    float sum = 0.0f;
    int count = 0;
    struct node *cur = head;
    while (cur) {
        sum += cur->data.gpa;
        count++;
        cur = cur->next;
    }
    return (count > 0) ? sum / count : 0.0f;
}


/*************** searching for the highest gpa ***************/

void searchHighestGPA(void) {
    if (!head) {
        printf("No students in the system.\n");
        return;
    }
    struct node *best = head;
    struct node *cur = head->next;
    while (cur) {
        if (cur->data.gpa > best->data.gpa) best = cur;
        cur = cur->next;
    }
    printf("Highest GPA student:\n");
    printf("ID: %d\nName: %s\nAge: %d\nGPA: %.2f\n",
           best->data.id, best->data.name, best->data.age, best->data.gpa);
}


/********************** choice menu **********************/

void menu(void) {
    char line[LINE_LEN];
    int choice;
    struct student temp;

    for (;;) {
        printf("\n--- Student Management System ---\n");
        printf("----------------------------------------\n");
        printf("1. Add a Student\n");
        printf("2. Display All Students\n");
        printf("3. Search for a Student by ID\n");
        printf("4. Update Student Information\n");
        printf("5. Delete a Student\n");
        printf("6. Calculate Average GPA\n");
        printf("7. Find Student with Highest GPA\n");
        printf("8. Exit\n");
        printf("Choose an option: \n");
        printf("----------------------------------------\n");
        read_line(line, sizeof(line));
        sscanf(line, "%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter ID: ");
                read_line(line, sizeof(line));
                sscanf(line, "%d", &temp.id);
                printf("Enter Name: ");
                read_line(temp.name, sizeof(temp.name));
                printf("Enter Age: ");
                read_line(line, sizeof(line));
                sscanf(line, "%d", &temp.age);
                printf("Enter GPA: ");
                read_line(line, sizeof(line));
                sscanf(line, "%f", &temp.gpa);
                addStudent(&temp);
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                printf("Enter ID: ");
                read_line(line, sizeof(line));
                sscanf(line, "%d", &choice);
                searchStudentByID(choice);
                break;
            case 4:
                printf("Enter ID: ");
                read_line(line, sizeof(line));
                sscanf(line, "%d", &choice);
                updateStudent(choice);
                break;
            case 5:
                printf("Enter ID: ");
                read_line(line, sizeof(line));
                sscanf(line, "%d", &choice);
                deleteStudent(choice);
                break;
            case 6:
                if (!head) {
                    printf("No students in the system.\n");
                } else {
                    printf("Average GPA: %.2f\n", calculateAverageGPA());
                }
                break;
            case 7:
                searchHighestGPA();
                break;
            case 8:
                printf("Exiting program.\n");
                return;
            default:
                printf("Invalid choice.\n");
        }
    }
}
/********************* main function *********************/
int main(void) {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

    menu();
    return 0;
}
